import os
import dspy

print("DSPY_MODEL =", os.environ.get("DSPY_MODEL"))
print("DSPY_API_BASE =", os.environ.get("DSPY_API_BASE"))

lm = dspy.LM(
    model=os.environ["DSPY_MODEL"],
    api_base=os.environ["DSPY_API_BASE"],
    api_key="EMPTY",
    max_tokens=32,
    temperature=0,
)

dspy.configure(lm=lm)

print(lm("Say hello in one short sentence."))