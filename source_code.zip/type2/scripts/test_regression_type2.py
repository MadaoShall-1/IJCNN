"""Regression tests for known Type2 failure patterns.

Tests the special-case handler and key deterministic templates to ensure
fixes for known error patterns remain correct.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from parser.schemas import ProblemParseObject
from type2.special_cases import try_special_case


def _make_parse(
    problem_text: str,
    known: dict,
    target: str,
    domains: list | None = None,
    sub_domains: list | None = None,
) -> ProblemParseObject:
    return ProblemParseObject(
        problem_text=problem_text,
        domains=domains or ["electrostatics"],
        sub_domains=sub_domains or [],
        known_quantities=known,
        unknown_quantity=target,
        step_plan=[],
    )


def _charge(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "C", "dimension": "charge"}


def _length(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "m", "dimension": "length"}


def _voltage(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "V", "dimension": "voltage"}


def _capacitance(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "F", "dimension": "capacitance"}


def _resistance(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "ohm", "dimension": "resistance"}


def _inductance(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "H", "dimension": "inductance"}


def _permittivity(val: float) -> dict:
    return {"value": val, "normalized_value": val, "unit_symbol": "", "dimension": "permittivity"}


def _assert_close(actual: float, expected: float, rel_tol: float = 0.02, label: str = ""):
    if expected == 0:
        assert abs(actual) < 1e-12, f"{label}: expected 0, got {actual}"
    else:
        assert math.isclose(actual, expected, rel_tol=rel_tol), \
            f"{label}: expected {expected}, got {actual} (ratio={actual/expected:.4f})"


# ──────────────────────────────────────────────────────────────────────────────
# Test cases
# ──────────────────────────────────────────────────────────────────────────────

def test_midpoint_equal_same_sign_E_zero():
    """LD079 / DT096 / DT099: Two equal same-sign charges → E at midpoint = 0."""
    parse = _make_parse(
        problem_text="Two point charges q1 = 5e-9 C and q2 = 5e-9 C are placed 10 cm apart in vacuum. "
                     "Calculate the magnitude of the electric field at the midpoint between the two charges.",
        known={"q1": _charge(5e-9), "q2": _charge(5e-9), "d": _length(0.1)},
        target="E",
    )
    result = try_special_case(parse, "LD079")
    assert result is not None, "Should match midpoint equal charges pattern"
    assert result.trace_status == "PASS"
    val = result.steps[0].output_var.get("E", -1)
    _assert_close(val, 0.0, label="LD079")
    print("  PASS: LD079 midpoint equal same-sign E=0")


def test_midpoint_opposite_charges_E():
    """LD031: Two equal opposite charges → E at midpoint adds."""
    parse = _make_parse(
        problem_text="In a vacuum, consider two electric charges q1 = -q2 = 10^-7 C placed at points A and B, "
                     "separated by 8 cm. Determine the resultant force acting on electric charge q0 = 10^-7 C "
                     "when q0 is placed at the midpoint of AB.",
        known={
            "q1": _charge(1e-7), "q2": _charge(-1e-7), "q0": _charge(1e-7),
            "d": _length(0.08),
        },
        target="F_net",
    )
    result = try_special_case(parse, "LD031")
    assert result is not None, "Should match midpoint opposite charges pattern"
    assert result.trace_status == "PASS"
    # F = q0 * E, E = 2*k*|q|/r², r = 0.04
    E = 2 * 9e9 * 1e-7 / (0.04**2)
    F_expected = 1e-7 * E  # = 0.1125 N
    val = None
    for step in result.steps:
        if "F_net" in step.output_var:
            val = step.output_var["F_net"]
    assert val is not None
    _assert_close(val, F_expected, label="LD031")
    print("  PASS: LD031 midpoint opposite charges F=0.1125 N")


def test_square_three_equal_charges_E():
    """LD068 / DT055: Three equal positive charges at 3 vertices → E at 4th vertex."""
    parse = _make_parse(
        problem_text="Three equal positive point charges, q = 5e-9 C, are placed at three vertices of a "
                     "square with side length a = 40 cm. What is the magnitude of the electric field at "
                     "the fourth vertex of the square?",
        known={"q": _charge(5e-9), "a": _length(0.4)},
        target="E",
    )
    result = try_special_case(parse, "LD068")
    assert result is not None, "Should match square three charges pattern"
    assert result.trace_status == "PASS"
    # E = (sqrt(2) + 0.5) * k * q / a²
    E_expected = (math.sqrt(2) + 0.5) * 9e9 * 5e-9 / (0.4**2)
    val = None
    for step in result.steps:
        if "E" in step.output_var:
            val = step.output_var["E"]
    assert val is not None
    _assert_close(val, E_expected, label="LD068")
    _assert_close(val, 538.0, rel_tol=0.01, label="LD068 vs gold")
    print(f"  PASS: LD068 square three charges E={val:.1f} N/C (expected ~538)")


def test_capacitor_disconnected_plate_doubled_V():
    """TD007 / TD010: Capacitor disconnected, plate distance doubled → V doubles."""
    parse = _make_parse(
        problem_text="A parallel-plate air capacitor with C = 2pF is charged to U = 600 V. "
                     "The capacitor is then disconnected from the power source, and its plates are moved "
                     "apart so that the distance between them doubles. Calculate the new voltage.",
        known={"C": _capacitance(2e-12), "V": _voltage(600)},
        target="V",
        domains=["circuits"],
        sub_domains=["capacitor"],
    )
    result = try_special_case(parse, "TD007")
    assert result is not None, "Should match capacitor disconnected plate doubled pattern"
    assert result.trace_status == "PASS"
    val = None
    for step in result.steps:
        if "V" in step.output_var:
            val = step.output_var["V"]
    assert val is not None
    _assert_close(val, 1200.0, label="TD007")
    print("  PASS: TD007 cap disconnected + plate doubled V=1200 V")


def test_capacitor_disconnected_dielectric_energy():
    """TD003: Capacitor disconnected + dielectric ε=2 → U = U₀/ε."""
    parse = _make_parse(
        problem_text="An air-filled parallel plate capacitor with capacitance C = 500 pF is charged to "
                     "a voltage U = 300 V. The capacitor is then disconnected from the source and immersed "
                     "in a liquid dielectric with a relative permittivity of ε_r = 2.",
        known={
            "C": _capacitance(500e-12),
            "V": _voltage(300),
            "epsilon_r": _permittivity(2),
        },
        target="U_cap",
        domains=["circuits"],
        sub_domains=["capacitor"],
    )
    result = try_special_case(parse, "TD003")
    assert result is not None, "Should match capacitor disconnected dielectric pattern"
    assert result.trace_status == "PASS"
    U0 = 0.5 * 500e-12 * 300**2  # 2.25e-5 J
    U_expected = U0 / 2  # 1.125e-5 J = 11.25 µJ
    val = None
    for step in result.steps:
        if "U_cap" in step.output_var:
            val = step.output_var["U_cap"]
    assert val is not None
    _assert_close(val, U_expected, label="TD003")
    print(f"  PASS: TD003 cap disconnected + dielectric U={val*1e6:.2f} µJ (expected 11.25)")


def test_capacitor_connected_dielectric_energy():
    """TD004: Capacitor connected + dielectric ε=2 → U = ε*U₀."""
    parse = _make_parse(
        problem_text="An air-filled parallel-plate capacitor with capacitance C = 500 pF is charged to "
                     "a voltage U = 300 V. The capacitor remains connected to the voltage source while "
                     "it is immersed in a liquid dielectric with a dielectric constant ε = 2.",
        known={
            "C": _capacitance(500e-12),
            "V": _voltage(300),
            "epsilon_r": _permittivity(2),
        },
        target="U_cap",
        domains=["circuits"],
        sub_domains=["capacitor"],
    )
    result = try_special_case(parse, "TD004")
    assert result is not None, "Should match capacitor connected dielectric pattern"
    assert result.trace_status == "PASS"
    U0 = 0.5 * 500e-12 * 300**2  # 2.25e-5 J
    U_expected = 2 * U0  # 4.5e-5 J = 45 µJ
    val = None
    for step in result.steps:
        if "U_cap" in step.output_var:
            val = step.output_var["U_cap"]
    assert val is not None
    _assert_close(val, U_expected, label="TD004")
    print(f"  PASS: TD004 cap connected + dielectric U={val*1e6:.2f} µJ (expected 45)")


def test_rlc_quality_factor():
    """CH372 / CH373 style: Q as quality factor, not charge."""
    parse = _make_parse(
        problem_text="A series RLC circuit has R = 10 Ω, L = 0.1 H, C = 100 µF. "
                     "Determine the quality factor Q of the circuit.",
        known={
            "R": _resistance(10),
            "L": _inductance(0.1),
            "C": _capacitance(1e-4),
        },
        target="Q",
        domains=["circuits"],
        sub_domains=["rlc_resonance"],
    )
    result = try_special_case(parse, "CH372")
    assert result is not None, "Should match RLC Q factor pattern"
    assert result.trace_status == "PASS"
    Q_expected = (1.0 / 10) * math.sqrt(0.1 / 1e-4)
    val = None
    for step in result.steps:
        if "Q_factor" in step.output_var:
            val = step.output_var["Q_factor"]
    assert val is not None
    _assert_close(val, Q_expected, label="CH372")
    print(f"  PASS: CH372 RLC Q factor = {val:.4f} (expected {Q_expected:.4f})")


def test_square_four_identical_charges_center_zero():
    """LD039: Four identical charges at square vertices → F at center = 0."""
    parse = _make_parse(
        problem_text="Four identical charges q1, q2, q3, q4 are placed at the four vertices of a square ABCD, "
                     "with a side length of 4 cm. Find the electric force acting on a charge q0 = 2e-8 C "
                     "placed at the center of the square.",
        known={
            "q": _charge(1e-8),
            "q0": _charge(2e-8),
            "a": _length(0.04),
        },
        target="F_net",
    )
    result = try_special_case(parse, "LD039")
    assert result is not None, "Should match four identical charges center pattern"
    assert result.trace_status == "PASS"
    val = result.steps[0].output_var.get("F_net", -1)
    _assert_close(val, 0.0, label="LD039")
    print("  PASS: LD039 four identical charges at square center F=0")


def test_square_opposite_pairs_E_zero():
    """LD059 / DT019: Square with +A,+C and -B,-D → E at center = 0."""
    parse = _make_parse(
        problem_text="Four charges of the same magnitude q are placed at the four vertices of a square "
                     "ABCD with side length a. Positive charges are located at A and C, while negative "
                     "charges are located at B and D. Determine the resultant electric field strength at "
                     "the intersection point of the square's diagonals.",
        known={"q": _charge(1e-9), "a": _length(0.1)},
        target="E",
    )
    result = try_special_case(parse, "LD059")
    assert result is not None, "Should match square opposite pairs pattern"
    assert result.trace_status == "PASS"
    val = result.steps[0].output_var.get("E", -1)
    _assert_close(val, 0.0, label="LD059")
    print("  PASS: LD059 square opposite pairs E at center = 0")


def test_no_false_positive():
    """A standard Coulomb problem should NOT be caught by special cases."""
    parse = _make_parse(
        problem_text="Two charges q1 = 3e-6 C and q2 = -5e-6 C are placed 20 cm apart. "
                     "Calculate the Coulomb force between them.",
        known={"q1": _charge(3e-6), "q2": _charge(-5e-6), "d": _length(0.2)},
        target="F_e",
    )
    result = try_special_case(parse, "GENERIC")
    assert result is None, "Should NOT match any special case (standard Coulomb)"
    print("  PASS: No false positive for standard Coulomb problem")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    tests = [
        test_midpoint_equal_same_sign_E_zero,
        test_midpoint_opposite_charges_E,
        test_square_three_equal_charges_E,
        test_capacitor_disconnected_plate_doubled_V,
        test_capacitor_disconnected_dielectric_energy,
        test_capacitor_connected_dielectric_energy,
        test_rlc_quality_factor,
        test_square_four_identical_charges_center_zero,
        test_square_opposite_pairs_E_zero,
        test_no_false_positive,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as exc:
            print(f"  FAIL: {test.__name__}: {exc}")
            failed += 1

    print(f"\n{'='*60}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed > 0:
        sys.exit(1)
    print("All regression tests passed!")


if __name__ == "__main__":
    main()
