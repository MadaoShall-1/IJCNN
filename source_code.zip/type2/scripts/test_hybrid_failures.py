"""Offline harness: run the REAL type2 pipeline (deterministic Stage 2 + Leg A
mechanics fast-paths + Leg B LLM->SymPy routing) on the official round-1 cases
and report answer/unit vs gold.

Run from the type2/ directory:  python -X utf8 scripts/test_hybrid_failures.py
"""
from __future__ import annotations
import json, re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]   # type2/
sys.path.insert(0, str(ROOT))

from config import SolverConfig
import type2.pipeline as P

EVAL = json.load(open(ROOT.parent / "exact_eval_round1_superNB.json", encoding="utf-8"))
T2 = {l["query_id"]: l for l in EVAL["logs"] if l.get("type") == "type2"}

FAILURES = ["T2_0004", "T2_0006", "T2_0008", "T2_0012", "T2_0013", "T2_0014",
            "T2_0015", "T2_0016", "T2_0018", "T2_0019", "T2_0020", "T2_0039", "T2_0049"]
PASSING_OOD = ["T2_0005", "T2_0007", "T2_0017", "T2_0029", "T2_0050"]


def _num(s: str):
    s = str(s).replace("×", "x").replace("^", "")
    m = re.search(r"[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?", s.replace(" x 10", "e"))
    if not m:
        # handle "7.20 x 10 3" style
        m2 = re.findall(r"[+-]?\d+(?:\.\d+)?", s)
        return float(m2[0]) * (10 ** float(m2[1])) if len(m2) >= 2 else None
    return float(m.group(0))


def _gold_num(ans: str):
    a = str(ans).replace("×", "x")
    m = re.match(r"\s*([+-]?\d+(?:\.\d+)?)\s*x\s*10\^?\s*([+-]?\d+)", a)
    if m:
        return float(m.group(1)) * 10 ** float(m.group(2))
    return _num(a)


def main() -> None:
    cfg = SolverConfig(beam_n=3)
    cfg.stage0_use_llm_fallback = False
    P._load_models(cfg)                 # deterministic Stage 2 (no DSPy SolveTrace)
    # Enable Leg B routing (uses the live vLLM directly, independent of SolveTrace):
    cfg.dspy_api_base = "http://localhost:8002/v1"
    cfg.dspy_model = "qwen3-8b-awq"
    cfg.dspy_max_tokens = 400

    def run(qid):
        l = T2[qid]; q = l["request_payload"]["query"]
        gold_a = l["expected"]["answer"]; gold_u = l["expected"]["unit"]
        payload = {"query_id": qid, "query": q, "type": "type2", "use_stage0_cache": False}
        t0 = time.monotonic()
        try:
            res = P._run_type2(payload, cfg, t0)
            sub = P._submission_result(payload, res, "type2")
            ans, unit, src = sub["answer"], sub["unit"], res.get("hybrid_source", "pipeline")
        except Exception as exc:
            ans, unit, src = f"<ERR {exc}>", "", "err"
        gn = _gold_num(gold_a); an = _num(ans)
        num_ok = gn is not None and an is not None and abs(an - gn) <= max(abs(gn) * 0.02, 1e-9)
        unit_ok = unit.replace(" ", "") == str(gold_u).replace(" ", "") or (not gold_u)
        verdict = "PASS" if (num_ok and unit_ok) else ("num~" if num_ok else "FAIL")
        print(f"  {qid} {verdict:4} ans={ans!r:14} unit={unit!r:7} [{src:11}] | gold={gold_a!r} {gold_u!r}")
        return num_ok and unit_ok

    print(f"solver mode: {P._type2_solver_mode}\n=== previously FAILING (target = fix) ===")
    f_ok = sum(run(q) for q in FAILURES)
    print(f"\n=== previously PASSING + OOD (must NOT regress) ===")
    p_ok = sum(run(q) for q in PASSING_OOD)
    print(f"\nfailures fixed: {f_ok}/{len(FAILURES)}   passing-OOD kept: {p_ok}/{len(PASSING_OOD)}")


if __name__ == "__main__":
    main()
